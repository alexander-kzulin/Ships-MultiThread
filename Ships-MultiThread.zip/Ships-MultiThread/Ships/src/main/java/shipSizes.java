public enum shipSizes {
    SMALL, MEDIUM, BIG
}
