import java.util.Random;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Ship implements Runnable{
private int id;
    private int loadLevel;
    private int shipSize;
    private String shipType;

    public Ship(int shipSize, String shipType) {
        this.shipSize = shipSize;
        this.shipType = shipType;
    }

    public Ship() {

    }

    public Ship(int id) {
        this.id = id;
    }


    public int getLoadLevel() {
        return loadLevel;
    }

    public int getShipSize() {
        shipSizes[] ships = shipSizes.values();
        int shipSizesidx = shipSizes.values().length;
        int generatedSize = new Random().nextInt(shipSizesidx);
        if (generatedSize == 1) {
            shipSize = 50;
        } else if (generatedSize == 2) {
            shipSize = 100;
        } else {
            shipSize = 150;
        }
        return shipSize;
    }

    public String getShipType() {
        int types = shiptypes.values().length;
        int shipsIndex = new Random().nextInt(shiptypes.values().length);
        if (shipsIndex == 0) {
            shipType = String.valueOf(shiptypes.TANKER);
        } else if (shipsIndex == 1) {
            shipType = String.valueOf(shiptypes.CRUISE);

        } else {
            shipType = String.valueOf(shiptypes.CONTAINERS);
        }
        return shipType;
    }

    @Override
    public String toString() {
        return "Ship{" +
                "shipSize=" + shipSize +
                ", shipType='" + shipType + '\'' +
                '}';
    }

    @Override
    public void run() {
        ShipGenerator shipGenerator = new ShipGenerator();
        shipGenerator.run();
    }
}

class ShipGenerator implements Runnable {
    private int id;
    public ShipGenerator(){}
    public ShipGenerator(int id) {
        this.id = id;
    }

    ExecutorService executorService = Executors.newFixedThreadPool(5);
    ArrayBlockingQueue<Ship> ships = new ArrayBlockingQueue<>(5);
    Ship ship = new Ship();
    @Override
    public void run() {
        try {
                ship.getShipSize();
                ship.getShipType();
                System.out.println("Ship is created " + ship);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
