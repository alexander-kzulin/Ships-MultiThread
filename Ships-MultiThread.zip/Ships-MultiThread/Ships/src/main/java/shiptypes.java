public enum shiptypes {
    TANKER , CRUISE, CONTAINERS
}
