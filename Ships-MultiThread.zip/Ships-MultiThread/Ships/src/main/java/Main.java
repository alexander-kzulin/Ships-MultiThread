import javax.swing.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) throws InterruptedException{
        Ship ship = new Ship();
        ShipGenerator shipGenerator = new ShipGenerator();
        shipGenerator.run();
        ExecutorService executorService = Executors.newFixedThreadPool(5);
        ArrayBlockingQueue<Ship> ships = new ArrayBlockingQueue<>(5);

        for(int i = 0; i < 5; i++)
            executorService.submit(new Ship(i));
        executorService.shutdown();


    }
}
